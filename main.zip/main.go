package main

import (
	"context"
	"fmt"
	"html"
	"net/http"
	"os"
	"strconv"
	"strings"
	"text/template"

	nested "github.com/antonfisher/nested-logrus-formatter"
	"github.com/mitchellh/go-ps"
	app "github.com/mt1976/proteushub/application"
	log "github.com/sirupsen/logrus"

	"github.com/docker/docker/api/types"
	"github.com/docker/docker/client"
	"github.com/gomarkdown/markdown"
	"github.com/toqueteos/webbrowser"

	human "github.com/dustin/go-humanize"
	"github.com/shirou/gopsutil/disk"
)

type PageData struct {
	AppName string
	Apps    []App
	Devices []DeviceInfo
}

type App struct {
	Name            string
	DescriptionFull string
	Description     string
	Badge           string
	BadgeContent    string
	Message         string
	Launchers       []Launcher
	Instance        string
	IconPath        string
	Version         string
	Display         string
	IconFileName    string
}

type Launcher struct {
	Name   string
	AppURI string
	Port   string
}

type DeviceInfo struct {
	Mountpoint   string
	Percent      float64
	Total        uint64
	Used         uint64
	Free         uint64
	HumanPercent string
	HumanTotal   string
	HumanUsed    string
	HumanFree    string
}

func main() {
	//fmt.Println("hello world")
	//test, _ := app.GetEnvironment()

	log.SetFormatter(&nested.Formatter{})

	app.Environment_Print()

	//test()

	// Setup Endpoints
	mux := http.NewServeMux()
	// At least one "mux" handler is required - Dont remove this
	mux.Handle("/assets/", http.StripPrefix("/assets/", http.FileServer(http.Dir("assets"))))
	mux.HandleFunc("/favicon.ico", faviconHandler)

	//mux.HandleFunc("/", TestPage)
	mux.HandleFunc("/", DisplayPage)

	listenON := app.ENV.AppPROTOCOL + "://" + app.ENV.AppURI + ":" + app.ENV.AppPORT
	log.WithField("URI", listenON).Info("Listening for Requests")
	//log.Info("Listening...")
	webbrowser.Open(listenON)
	listenPort := app.ENV.AppPORT
	log.Fatal(http.ListenAndServe(":"+listenPort, mux))

}

func faviconHandler(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, "favicon.ico")
}

func DisplayPage(w http.ResponseWriter, _ *http.Request) {

	//fmt.Fprintf(w, "Hello, there\n")

	app.Reload()

	dhost := app.ENV.DockerPROTOCOL + "://" + app.ENV.DockerURI + ":" + app.ENV.DockerPORT

	log.WithField("Host", dhost).Info("Docker - Connecting...")

	cli, err := client.NewClientWithOpts(client.FromEnv)
	if err != nil {
		panic(err)
	}

	containers, err := cli.ContainerList(context.Background(), types.ContainerListOptions{})
	if err != nil {
		panic(err)
	}

	log.WithField("Host", dhost).Info("Docker - Connected")

	thisPage := PageData{}
	thisPage.AppName = app.ENV.AppName

	//extensions := parser.CommonExtensions | parser.AutoHeadingIDs
	//parser := parser.NewWithExtensions(extensions)

	//log.Info("Containers List")
	for _, container := range containers {

		thisApp := App{}
		thisApp.Name = html.EscapeString(container.Labels["org.opencontainers.image.title"])
		//log.Info("Processing: " + "MD")
		//log.WithField("data", string(md)).Info("Processing: " + "MD")

		thisApp.Message = container.Status
		thisApp.Instance = container.Names[0][1:]
		//log.Infoln("Processing: /" + thisApp.Instance + "/")
		//if thisApp.Name == "" {
		thisApp.Name = getOVRvalue(thisApp.Name, thisApp.Instance, "name")
		//}

		//	thisApp.Name = getOVRvalue(app.ENV.AppPROTOCOL, thisApp.Instance, "name")
		skip := getOVRvalue("false", thisApp.Instance, "hide")
		log.WithFields(log.Fields{"name": thisApp.Name, "instance": thisApp.Instance, "skip": skip}).Info("Skip Test: ")
		if skip == "true" {
			continue
		}
		data := container.Labels["org.opencontainers.image.description"]
		op := getHTMLDescription(getEXTvalue(data, thisApp.Instance, "description"))

		//log.WithField("op", string(op)).Info("Processing: " + "MD")
		//log.Info("Processing: " + "MD END")
		thisApp.DescriptionFull = op
		thisApp.Description = op

		thisApp.IconPath = ""
		thisApp.Version = container.Labels["org.opencontainers.image.version"]
		thisApp.Display, thisApp.IconFileName = getServiceFaviconHTML(thisApp)

		switch container.State {
		case "running":
			thisApp.Badge = "success"
			thisApp.BadgeContent = "Running"
		case "exited":
			thisApp.Badge = "danger"
			thisApp.BadgeContent = "Exited"
		case "created":
			thisApp.Badge = "warning"
			thisApp.BadgeContent = "Created"
		case "paused":
			thisApp.Badge = "info"
			thisApp.BadgeContent = "Paused"
		case "restarting":
			thisApp.Badge = "info"
			thisApp.BadgeContent = "Restarting"
		case "removing":
			thisApp.Badge = "info"
			thisApp.BadgeContent = "Removing"
		case "dead":
			thisApp.Badge = "danger"
			thisApp.BadgeContent = "Dead"
		default:
			thisApp.Badge = "dark"
			thisApp.BadgeContent = "Unknown"
		}

		noPorts := len(container.Ports)
		//log.Info("No of Ports: " + strconv.Itoa(noPorts))
		for i := 0; i < noPorts; i++ {
			//			log.Info("Port: " + strconv.Itoa(int(container.Ports[i].PublicPort)))
			//			log.Info("Int: " + strconv.Itoa(int(container.Ports[i].PrivatePort)))
			nL := Launcher{}
			nL.Name = container.Labels["org.opencontainers.image.title"]
			if nL.Name == "" {
				nL.Name = getOVRvalue(app.ENV.AppPROTOCOL, thisApp.Instance, "name")
			}
			pc := getOVRvalue(app.ENV.AppPROTOCOL, thisApp.Instance, "protocol")

			nL.AppURI = pc + "://" + app.ENV.AppURI + ":" + strconv.Itoa(int(container.Ports[i].PublicPort)) + "/"
			nL.Port = strconv.Itoa(int(container.Ports[i].PublicPort))
			addPort, err := checkPort(thisApp.Instance, nL.Port)
			if err != nil {
				panic(err)
			}
			if addPort {
				thisApp.Launchers = append(thisApp.Launchers, nL)
				//	logApp(thisApp)
			}
		}
		//spew.Dump(thisApp)
		thisPage.Apps = append(thisPage.Apps, thisApp)
	}

	if app.ENV.AdditionalServices {
		//log.Info("Adding Additional Services")
		//noSvc := len(app.ENV.AdditionalServicesList)
		//fmt.Printf("noSvc: %v\n", noSvc)
		//fmt.Printf("app.ENV.AdditionalServicesList: %v\n", app.ENV.AdditionalServicesList)
		for _, v := range app.ENV.AdditionalServicesList {
			//		log.WithFields(log.Fields{"index": i, "name": v}).Info("Service")

			//	thisApp.Name = getOVRvalue(app.ENV.AppPROTOCOL, thisApp.Instance, "name")
			skip := getOVRvalue("false", v, "hide")
			//log.WithFields(log.Fields{"name": v, "instance": v, "skip": skip}).Info("Skip Test: ")
			if skip == "true" {
				continue
			}

			svcDef, _ := getServiceDefinition(v)

			thisPage.Apps = append(thisPage.Apps, svcDef)
			//logApp(svcDef)
		}
	}

	x := len(thisPage.Apps)
	//log.Info("No of Apps: " + strconv.Itoa(x))
	for i := 0; i < x; i++ {
		//	log.Info("SEQ: " + strconv.Itoa(i))
		logAppDetail(i, thisPage.Apps[i])
	}

	thisPage.Devices = GetDeviceInfo()
	//fmt.Printf("thisPage.Devices: %v\n", thisPage.Devices)

	//	fmt.Printf("thisPage: %v\n", thisPage)
	//	fmt.Fprintln(w, "thisPage: ", thisPage)

	tmplName := "html/" + app.ENV.AppTemplate + ".html"

	t := template.Must(template.ParseFiles(tmplName)) // Create a template.
	//	t, _ = t.ParseFiles("html/"+app.ENV.AppTemplate+".html", nil) // Parse template file.
	w.Header().Set("Content-Type", "text/html")
	t.Execute(w, thisPage) // merge.
}

func GetDeviceInfo() []DeviceInfo {

	//	fmt.Printf("TestPage\n")

	rtnVal := []DeviceInfo{}

	//formatter := "%-14s %7s %7s %7s %4s %s\n"
	//fmt.Printf(formatter, "Filesystem", "Size", "Used", "Avail", "Use%", "Mounted on")

	parts, _ := disk.Partitions(true)
	for _, p := range parts {
		info := DeviceInfo{}
		device := p.Mountpoint
		s, _ := disk.Usage(device)

		if s.Total == 0 {
			continue
		}

		percent := fmt.Sprintf("%2.f%%", s.UsedPercent)

		//

		info.Mountpoint = p.Mountpoint
		info.Percent = s.UsedPercent
		info.Total = s.Total
		info.Used = s.Used
		info.Free = s.Free

		info.HumanPercent = percent
		info.HumanTotal = human.Bytes(s.Total)
		info.HumanUsed = human.Bytes(s.Used)
		info.HumanFree = human.Bytes(s.Free)

		rtnVal = append(rtnVal, info)
		log.WithFields(log.Fields{"mountpoint": info.Mountpoint, "percent": info.HumanPercent, "used": info.HumanUsed, "free": info.HumanFree, "total": info.HumanTotal}).Info("Device")
	}
	return rtnVal
}

func getHTMLDescription(data string) string {
	md := []byte(data)

	op := markdown.ToHTML(md, nil, nil)
	return string(op)
}

// func truncateText(s string, max int) string {
// 	if max > len(s) {
// 		return s
// 	}
// 	return s[:strings.LastIndexAny(s[:max], " .,:;-")]
// }

func checkPort(inInstance string, inPort string) (bool, error) {
	//log.WithFields(log.Fields{"instance": inInstance, "port": inPort}).Info("Checking Port Validity")
	test := getOVRvalue("", inInstance, "port")
	//app.OVR[inInstance+"ports"]
	//fmt.Printf("test: %v\n", test)
	if test == inPort {
		return true, nil
	}
	if test == "" {
		return true, nil
	}
	return false, nil
}

func getServiceDefinition(inName string) (App, error) {

	newApp := App{}
	//x := newFunction(inName,"name")
	newApp.Name = getEXTvalue(inName, inName, "name")
	newApp.Instance = getEXTvalue(inName, inName, "instance")
	op := getHTMLDescription(getEXTvalue("descr", inName, "description"))
	newApp.Description = op
	newApp.DescriptionFull = op

	newApp.Badge = getEXTvalue("info", inName, "badge")
	newApp.BadgeContent = getEXTvalue("Unknown", inName, "badgeContent")

	pName := getEXTvalue("", inName, "processname")
	if pName != "" {
		pStatus, _ := getProcessStatus(pName)
		if pStatus != "" {
			newApp.Badge = "success"
			newApp.BadgeContent = pStatus
		} else {
			newApp.Badge = "dark"
			newApp.BadgeContent = "Not Running"
		}
	}

	newURI := getEXTvalue("http", inName, "protocol") + "://" + getEXTvalue("127.0.0.1", inName, "ip") + ":" + getEXTvalue("", inName, "port") + "/"
	uriPath := getEXTvalue("", inName, "path")
	if uriPath != "" {
		newURI = newURI + uriPath
	}

	newApp.Launchers = append(newApp.Launchers, Launcher{Name: newApp.Name, AppURI: newURI, Port: getEXTvalue("", inName, "port")})
	newApp.Message = getEXTvalue("-", inName, "message")
	newApp.Display, newApp.IconFileName = getServiceFaviconHTML(newApp)
	//newApp.IconFileName
	logAppDetail(0, newApp)

	return newApp, nil
}

func getServiceFaviconHTML(newApp App) (string, string) {
	defaultIcon := "<i class=\"fas fa-server fa-3x mb-3\"></i>"
	fn := strings.Split(newApp.Instance, "-")
	iconfile := fn[0] + ".png"
	//log.Println("iconfile: " + iconfile)
	//log.Info("Setting Icon : ", newApp.Instance, " ", iconfile)
	// check if file exists in /icons
	if _, err := os.Stat("assets/icons/" + iconfile); err == nil {
		//	log.Info("Icon Found : ", iconfile)
		return "<img src=\"assets/icons/" + iconfile + "\" class=\"img-display fa-2x\" alt=\"" + newApp.Name + "\" />", iconfile
	}
	return defaultIcon, iconfile
}

func getOVRvalue(orig string, inName string, what string) string {
	// fmt.Printf("orig: %v\n", orig)
	// fmt.Printf("inName: %v\n", inName)
	// fmt.Printf("what: %v\n", what)
	val := getValue(app.OVR, inName, what)

	//log.WithFields(log.Fields{"orig": orig, "in": inName, "what": what, "value": val}).Info("OVR")

	if val == "" {
		return orig
	}
	// fmt.Printf("val: %v\n", val)
	return val
}

func getEXTvalue(orig string, inName string, what string) string {
	//retVal := orig
	out := getValue(app.EXT, inName, what)
	if out == "" {
		out = orig
	}
	//log.Info("EXT: ", orig, ":", inName, ":", what, ":", out, ":")
	out = getOVRvalue(out, inName, what)
	//if out2 == "" {
	//log.Info("OVR: |", inName, "|", what, "|", out, "|", orig, "|")
	return out
}

func getValue(prop map[string]string, inName string, what string) string {
	search := inName + what
	rVal := prop[search]
	//if rVal == "" {
	//		return inName
	//	}
	return rVal
}

// func logApp(thisApp App) {
// 	log.WithFields(log.Fields{"name": thisApp.Instance,
// 		"app":     thisApp.Name,
// 		"uri":     thisApp.Launchers[len(thisApp.Launchers)-1].AppURI,
// 		"port":    thisApp.Launchers[len(thisApp.Launchers)-1].Port,
// 		"Status":  thisApp.BadgeContent,
// 		"State":   thisApp.Message,
// 		"Version": thisApp.Version}).Info("Service")
// }

func logAppDetail(i int, thisApp App) {
	//log.Info("LOGGING SEQ: " + strconv.Itoa(i))
	//log.Info("LAUNCERS APP: " + strconv.Itoa(len(thisApp.Launchers)))
	lchr := len(thisApp.Launchers) - 1
	aURI := "N/A"
	aPort := "N/A"
	//log.Info(thisApp.Launchers)

	if lchr >= 0 {
		aURI = thisApp.Launchers[lchr].AppURI
		aPort = thisApp.Launchers[lchr].Port
	}
	log.WithFields(log.Fields{
		"index":     i,
		"name":      thisApp.Instance,
		"app":       thisApp.Name,
		"launchers": len(thisApp.Launchers),
		"uri":       aURI,
		"port":      aPort,
		"Status":    thisApp.BadgeContent,
		"State":     thisApp.Message,
		"Version":   thisApp.Version,
		"Icon":      thisApp.IconFileName}).Info("Service")
}

func findProcessByName(inProcessName string) (int, error) {
	processes, err := ps.Processes()
	if err != nil {
		return 0, err
	} // end if
	for _, process := range processes {
		processName := process.Executable()
		processName = strings.ReplaceAll(processName, "/", "")
		processName = strings.ReplaceAll(processName, ".exe", "")
		//fmt.Println("processName", processName)
		if processName == inProcessName {
			return process.Pid(), nil
		} // end if
	}
	return 0, fmt.Errorf("Process %s not found", inProcessName)
}

func getProcessStatus(inProcessName string) (string, error) {

	// log.Info("getProcessStatus " + inProcessName)
	// log.Info("getProcessStatus " + inProcessName)
	// log.Info("getProcessStatus " + inProcessName)
	// log.Info("getProcessStatus " + inProcessName)
	// log.Info("getProcessStatus " + inProcessName)
	// log.Info("getProcessStatus " + inProcessName)

	_, err := findProcessByName(inProcessName)
	if err != nil {
		return "Unknown", nil
	} // end if

	return "Running", nil
}
